package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;
import lombok.*;

@Entity
@Table(name = "payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private String paymentMethod;

    @Column(nullable = false)
    private Double totalAmount;

    @Embedded
    private Address address;

    @Column(nullable = false)
    private LocalDateTime paymentDate;

    @Column(nullable = false)
    private String status;
    
    // Additional fields for card payments
    private String cardNumber;
    private String expiryDate;
    private String cvv;
    private String cardName;

    // Additional field for UPI payment
    private String upiId;

    // Constructor, Getters, and Setters
}
